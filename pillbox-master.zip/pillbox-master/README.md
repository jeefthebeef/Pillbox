# pillbox
A smart-pillbox that's linked to a phone app through bluetooth and opens containers throughout the day to remind patients, especially elderly ones, to take the correct amount of pills at the right times. A buzzer is included as a sound reminder.

Not yet completed. Built with an Arduino 101 in BLE.
